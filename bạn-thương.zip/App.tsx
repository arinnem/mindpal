
import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import GlobalHeader from './components/GlobalHeader';
import GlobalFooter from './components/GlobalFooter';
import HomePage from './pages/HomePage';
import JournalPage from './pages/JournalPage';
import ThoughtMonstersPage from './pages/ThoughtMonstersPage';
import ExplorePage from './pages/ExplorePage';
import SupportPage from './pages/SupportPage';
import { CrisisAlertProvider } from './hooks/useCrisisAlert';

const App: React.FC = () => {
  return (
    <CrisisAlertProvider>
      <HashRouter>
        <div className="flex flex-col min-h-screen bg-warm-linen text-warm-charcoal">
          <GlobalHeader />
          <main className="flex-grow container mx-auto px-4 py-8">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/journal" element={<JournalPage />} />
              <Route path="/monsters" element={<ThoughtMonstersPage />} />
              <Route path="/explore" element={<ExplorePage />} />
              <Route path="/support" element={<SupportPage />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>
          <GlobalFooter />
        </div>
      </HashRouter>
    </CrisisAlertProvider>
  );
};

export default App;