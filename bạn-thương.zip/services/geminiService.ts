
import { GoogleGenAI, Chat, GenerateContentResponse, Part, GenerateContentParameters, GenerateImagesResponse, Image, GeneratedImage, Content } from "@google/genai";
import { DEFAULT_GEMINI_TEXT_MODEL, DEFAULT_GEMINI_IMAGE_MODEL } from '../constants';
import { GroundingChunk } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY for Gemini is not set. AI features will not work. Please set the process.env.API_KEY environment variable.");
}
// Initialize GoogleGenAI with a check for API_KEY to prevent errors if not set
// In a real app, you might want to disable AI features or show a message if API_KEY is missing.
const ai = API_KEY ? new GoogleGenAI({ apiKey: API_KEY }) : null;

const parseJsonFromText = <T,>(text: string): T | null => {
  let jsonStr = text.trim();
  const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches ```json ... ``` or ``` ... ```
  const match = jsonStr.match(fenceRegex);
  if (match && match[2]) {
    jsonStr = match[2].trim();
  }
  try {
    return JSON.parse(jsonStr) as T;
  } catch (error) {
    console.error("Failed to parse JSON from text:", error, "Original text:", text);
    return null;
  }
};


export const geminiService = {
  generateText: async (
    prompt: string, 
    systemInstruction?: string, 
    useGoogleSearch: boolean = false
  ): Promise<{text: string, groundingChunks?: GroundingChunk[]}> => {
    if (!ai) return { text:"API Key not configured. AI service unavailable."};
    try {
      const params: GenerateContentParameters = {
        model: DEFAULT_GEMINI_TEXT_MODEL,
        contents: prompt,
        config: {}
      };

      if (systemInstruction && params.config) {
        params.config.systemInstruction = systemInstruction;
      }
      
      if (useGoogleSearch && params.config) {
        params.config.tools = [{googleSearch: {}}];
      } else if (params.config) {
        // Only set responseMimeType if not using Google Search
        // params.config.responseMimeType = "text/plain"; 
      }


      const response: GenerateContentResponse = await ai.models.generateContent(params);
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;
      return {text: response.text, groundingChunks };
    } catch (error) {
      console.error("Error generating text:", error);
      return {text: "Xin lỗi, tớ đang gặp chút trục trặc và chưa thể trả lời lúc này."};
    }
  },

  generateTextWithJsonOutput: async <T,>(
    prompt: string, 
    systemInstruction?: string
  ): Promise<T | null> => {
    if (!ai) {
      console.error("API Key not configured. AI service unavailable.");
      return null;
    }
    try {
      const params: GenerateContentParameters = {
        model: DEFAULT_GEMINI_TEXT_MODEL,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
        }
      };
       if (systemInstruction && params.config) {
        params.config.systemInstruction = systemInstruction;
      }

      const response: GenerateContentResponse = await ai.models.generateContent(params);
      return parseJsonFromText<T>(response.text);
    } catch (error) {
      console.error("Error generating JSON:", error);
      return null;
    }
  },

  startChatSession: async (systemInstruction?: string, history?: Content[]): Promise<Chat | null> => {
    if (!ai) return null;
    try {
      // Define a more specific type for chatConfig if needed, or use the structure directly
      const chatConfig: {
        model: string;
        config?: { systemInstruction?: string };
        history?: Content[];
      } = { model: DEFAULT_GEMINI_TEXT_MODEL };
      
      if (systemInstruction) {
        chatConfig.config = { systemInstruction };
      }
      if(history){
        chatConfig.history = history;
      }
      return ai.chats.create(chatConfig);
    } catch (error) {
      console.error("Error starting chat session:", error);
      return null;
    }
  },

  sendMessageInChat: async (chat: Chat, message: string): Promise<{text: string, groundingChunks?: GroundingChunk[]}> => {
    if (!ai) return {text: "API Key not configured. AI service unavailable."};
    try {
      const response: GenerateContentResponse = await chat.sendMessage({ message });
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined;
      return {text: response.text, groundingChunks};
    } catch (error) {
      console.error("Error sending message in chat:", error);
      return {text: "Tớ xin lỗi, có vẻ như tớ đang không thể tiếp tục cuộc trò chuyện."};
    }
  },

  generateImage: async (prompt: string): Promise<string | null> => {
    if (!ai) return null;
    try {
      const response: GenerateImagesResponse = await ai.models.generateImages({
        model: DEFAULT_GEMINI_IMAGE_MODEL,
        prompt: prompt,
        config: { numberOfImages: 1, outputMimeType: 'image/png' },
      });
      if (response.generatedImages && response.generatedImages.length > 0) {
        const generatedImage: GeneratedImage = response.generatedImages[0]; // This is of type GeneratedImage
        // The 'Image' type (e.g. Image_2) is on generatedImage.image
        if (generatedImage.image && generatedImage.image.imageBytes) {
          const base64ImageBytes: string = generatedImage.image.imageBytes;
          return `data:image/png;base64,${base64ImageBytes}`;
        }
      }
      return null;
    } catch (error) {
      console.error("Error generating image:", error);
      return null;
    }
  },

  // Stream variant for chat
  sendMessageInChatStream: async function* (chat: Chat, message: string) {
    if (!ai) {
      yield { text: "API Key not configured. AI service unavailable.", isError: true };
      return;
    }
    try {
      const responseStream = await chat.sendMessageStream({ message });
      for await (const chunk of responseStream) {
        yield { text: chunk.text, groundingChunks: chunk.candidates?.[0]?.groundingMetadata?.groundingChunks as GroundingChunk[] | undefined };
      }
    } catch (error) {
      console.error("Error sending message in chat stream:", error);
      yield { text: "Tớ xin lỗi, có lỗi xảy ra khi đang trò chuyện.", isError: true };
    }
  }
};
