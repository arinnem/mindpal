
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ChatMessage, Mood, GroundingChunk } from '../types';
import { geminiService } from '../services/geminiService';
import Button from './Button';
import { SendIcon } from './icons/SendIcon';
import { UserCircleIcon } from './icons/UserCircleIcon';
import { SparklesIcon } from './icons/SparklesIcon';
import { useCrisisAlert } from '../hooks/useCrisisAlert';
import { Chat, Part, Content } from '@google/genai'; // Corrected import (Content added, type keyword removed for Chat,Part,Content)

interface ChatInterfaceProps {
  initialMessage?: string;
  initialMood?: Mood;
  systemInstruction?: string;
  onCloseChat?: () => void; // Optional: To allow closing/minimizing chat
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ initialMessage, initialMood, systemInstruction, onCloseChat }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chatSession, setChatSession] = useState<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { checkTextForCrisis, isCrisisAlertVisible } = useCrisisAlert();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  const initializeChat = useCallback(async () => {
    setIsLoading(true);
    let effectiveSystemInstruction = systemInstruction || "Bạn là một người bạn đồng hành AI tên là 'Bạn Thương', luôn lắng nghe, thấu hiểu và trò chuyện một cách ấm áp, dịu dàng với học sinh Việt Nam. Hãy sử dụng ngôn ngữ trong sáng, tích cực và phù hợp với lứa tuổi này.";
    if (initialMood) {
      effectiveSystemInstruction += ` Người dùng vừa cho biết họ đang cảm thấy ${initialMood}. Hãy bắt đầu cuộc trò chuyện một cách phù hợp với tâm trạng này.`;
    }

    const history: Content[] = []; // Changed Part[] to Content[]
    if(initialMessage) {
        // This is now type-correct as history is Content[] and Content has role & parts
        history.push({role: "user", parts: [{text: initialMessage}]}); 
    }
    
    const session = await geminiService.startChatSession(effectiveSystemInstruction, history.length > 0 ? history : undefined);
    setChatSession(session);

    if (initialMessage && session) {
      // If there was an initial message, get AI's first response
      // This assumes the history already contains the initial user message if sent to startChatSession.
      // If startChatSession doesn't auto-reply based on history, we might need to send it explicitly.
      // The current geminiService.startChatSession seems to just initialize.
      // So, the first AI response should come from sending the initialMessage.
      const aiResponse = await geminiService.sendMessageInChat(session, initialMessage); // The message here is effectively the first actual message in the new session.
      setMessages(prev => [
        ...prev, // prev should contain the initial user message if it was added outside.
        { id: Date.now().toString() + 'ai', text: aiResponse.text, sender: 'ai', timestamp: new Date(), metadata: {groundingChunks: aiResponse.groundingChunks} }
      ]);
    } else if (session && initialMood && !initialMessage) {
      // If only mood, AI can initiate based on system instruction
       const greetingBasedOnMood = `Chào bạn, tớ thấy bạn đang cảm thấy ${initialMood}. Có chuyện gì muốn chia sẻ với tớ không?`;
       // The greetingBasedOnMood is conceptually the first "user" utterance to kick off the AI's response in this scenario.
       const aiResponse = await geminiService.sendMessageInChat(session, greetingBasedOnMood); 
       setMessages(prev => [
        ...prev,
        { id: Date.now().toString() + 'ai', text: aiResponse.text, sender: 'ai', timestamp: new Date(), metadata: {groundingChunks: aiResponse.groundingChunks} }
      ]);
    }
    setIsLoading(false);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialMood, systemInstruction]); // Removed initialMessage from deps to avoid re-init on message send

  useEffect(() => {
    // Add initial user message to chat display if provided
    if (initialMessage) {
        setMessages([{ id: Date.now().toString() + 'user', text: initialMessage, sender: 'user', timestamp: new Date() }]);
    }
    initializeChat();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initializeChat]); // Removed initialMessage from here to rely on initializeChat's logic

  const handleSendMessage = async () => {
    if (inputValue.trim() === '' || isLoading || !chatSession || isCrisisAlertVisible) return;

    const userMessageContent = inputValue;
    setInputValue('');

    if (checkTextForCrisis(userMessageContent)) {
      // Crisis alert is handled by the hook, prevent sending message to AI
      setMessages(prev => [...prev, { id: Date.now().toString(), text: userMessageContent, sender: 'user', timestamp: new Date() }]);
      return;
    }

    setMessages(prev => [...prev, { id: Date.now().toString(), text: userMessageContent, sender: 'user', timestamp: new Date() }]);
    setIsLoading(true);

    // Using stream for better UX
    let fullAiResponseText = "";
    // let finalGroundingChunks: GroundingChunk[] | undefined = undefined; // Not used currently, but kept for potential future use
    const aiMessageId = Date.now().toString() + 'ai-stream';

    // Add a placeholder for AI message
    setMessages(prev => [...prev, { id: aiMessageId, text: "...", sender: 'ai', timestamp: new Date() }]);

    const stream = geminiService.sendMessageInChatStream(chatSession, userMessageContent);
    for await (const chunk of stream) {
      if (chunk.text) {
        fullAiResponseText += chunk.text;
        setMessages(prev => prev.map(msg => 
          msg.id === aiMessageId ? { ...msg, text: fullAiResponseText, metadata: { groundingChunks: chunk.groundingChunks } } : msg
        ));
        // if(chunk.groundingChunks) finalGroundingChunks = chunk.groundingChunks; // Update if needed
      }
      if (chunk.isError) { // Handle error from stream
         setMessages(prev => prev.map(msg => 
          msg.id === aiMessageId ? { ...msg, text: chunk.text || "Lỗi khi nhận phản hồi." } : msg
        ));
        break; 
      }
    }
    
    setIsLoading(false);
    scrollToBottom();
  };


  return (
    <div className="flex flex-col h-full max-h-[calc(100vh-200px)] bg-warm-linen rounded-lg shadow-xl overflow-hidden border border-soft-clay/20">
      {onCloseChat && (
         <div className="p-3 border-b border-soft-clay/20 flex justify-between items-center">
            <h2 className="text-lg font-semibold font-display text-soft-clay">Trò chuyện cùng Bạn Thương</h2>
            <Button size="sm" variant="outline" onClick={onCloseChat}>Đóng</Button>
         </div>
      )}
      <div className="flex-grow p-4 md:p-6 space-y-4 overflow-y-auto">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[70%] p-3 rounded-2xl shadow ${
              msg.sender === 'user' 
                ? 'bg-soft-clay text-warm-linen rounded-br-none' 
                : 'bg-sage-green/30 text-warm-charcoal rounded-bl-none'
            }`}>
              <div className="flex items-start space-x-2 mb-1">
                {msg.sender === 'ai' ? <SparklesIcon className="w-5 h-5 text-sage-green" /> : <UserCircleIcon className="w-5 h-5 text-warm-linen/80" />}
                <p className="text-sm" style={{ whiteSpace: 'pre-wrap'}}>{msg.text}</p>
              </div>
              {msg.metadata?.groundingChunks && (msg.metadata.groundingChunks as GroundingChunk[]).length > 0 && (
                <div className="mt-2 pt-2 border-t border-current/20">
                  <p className="text-xs font-semibold mb-1">Nguồn tham khảo:</p>
                  <ul className="list-disc list-inside space-y-1">
                    {(msg.metadata.groundingChunks as GroundingChunk[]).map((chunk, idx) => (
                       chunk.web?.uri && (
                        <li key={idx} className="text-xs">
                          <a href={chunk.web.uri} target="_blank" rel="noopener noreferrer" className="hover:underline opacity-80 hover:opacity-100">
                            {chunk.web.title || chunk.web.uri}
                          </a>
                        </li>
                       )
                    ))}
                  </ul>
                </div>
              )}
              <p className="text-xs opacity-60 mt-1 text-right">{new Date(msg.timestamp).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })}</p>
            </div>
          </div>
        ))}
        {isLoading && messages.length > 0 && messages[messages.length -1]?.sender === 'user' && (
          <div className="flex justify-start">
            <div className="max-w-[70%] p-3 rounded-2xl shadow bg-sage-green/30 text-warm-charcoal rounded-bl-none">
              <div className="flex items-center space-x-2">
                <SparklesIcon className="w-5 h-5 text-sage-green" />
                <p className="text-sm animate-pulse">Bạn Thương đang gõ...</p>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 md:p-6 border-t border-soft-clay/20 bg-warm-linen/50">
        <div className="flex items-center space-x-3">
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
            placeholder={isCrisisAlertVisible ? "Hãy liên hệ các số điện thoại ở trên..." : "Nhắn gửi yêu thương..."}
            className="flex-grow p-3 border border-sage-green/50 rounded-lg focus:ring-2 focus:ring-soft-clay focus:border-soft-clay transition-shadow bg-white"
            disabled={isLoading || isCrisisAlertVisible}
          />
          <Button onClick={handleSendMessage} isLoading={isLoading} disabled={isCrisisAlertVisible || inputValue.trim() === ''} aria-label="Gửi tin nhắn">
            <SendIcon className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;
