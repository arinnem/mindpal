
import React from 'react';
import { NavLink } from 'react-router-dom';
import { APP_NAME } from '../constants';

const GlobalHeader: React.FC = () => {
  const navItems = [
    { path: '/', label: 'Trang chủ' },
    { path: '/journal', label: 'Tâm sự mỏng' },
    { path: '/monsters', label: 'Hình dáng tôi' },
    { path: '/explore', label: 'Khám phá' },
    { path: '/support', label: 'Hỗ trợ' },
  ];

  return (
    <header className="sticky top-0 z-50 bg-warm-linen/80 backdrop-blur-md shadow-sm">
      <nav className="container mx-auto px-4 py-3 flex justify-between items-center">
        <NavLink to="/" className="text-2xl font-bold font-display text-soft-clay hover:text-opacity-80 transition-colors">
          {APP_NAME}
        </NavLink>
        <ul className="flex space-x-6">
          {navItems.map((item) => (
            <li key={item.path}>
              <NavLink
                to={item.path}
                className={({ isActive }) =>
                  `text-warm-charcoal hover:text-soft-clay transition-colors pb-1 ${
                    isActive ? 'font-semibold border-b-2 border-soft-clay' : ''
                  }`
                }
              >
                {item.label}
              </NavLink>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
};

export default GlobalHeader;
