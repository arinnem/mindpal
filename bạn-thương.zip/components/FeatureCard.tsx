
import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRightIcon } from './icons/ArrowRightIcon';


interface FeatureCardProps {
  title: string;
  description: string;
  linkTo: string;
  imageUrl?: string;
  accentColor?: string; // e.g., 'bg-soft-clay', 'bg-sage-green'
}

const FeatureCard: React.FC<FeatureCardProps> = ({ title, description, linkTo, imageUrl, accentColor = 'bg-soft-clay' }) => {
  return (
    <Link 
      to={linkTo} 
      className="block bg-warm-linen p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 ease-in-out transform hover:-translate-y-1 group"
    >
      {imageUrl && (
        <div className="w-full h-40 mb-4 rounded-lg overflow-hidden">
          <img src={imageUrl} alt={title} className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105" />
        </div>
      )}
      <div className={`w-12 h-1 ${accentColor} mb-3 rounded-full`}></div>
      <h3 className="text-xl font-semibold font-display text-warm-charcoal mb-2 group-hover:text-soft-clay transition-colors">
        {title}
      </h3>
      <p className="text-sm text-warm-charcoal/80 mb-4">
        {description}
      </p>
      <div className="inline-flex items-center text-sm text-soft-clay font-medium group-hover:underline">
        Khám phá ngay <ArrowRightIcon className="ml-1 w-4 h-4" />
      </div>
    </Link>
  );
};

export default FeatureCard;
