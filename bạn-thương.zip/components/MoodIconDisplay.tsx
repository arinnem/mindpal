
import React from 'react';
import { MoodOption, Mood } from '../types';

interface MoodIconDisplayProps {
  mood: MoodOption;
  isSelected: boolean;
  onSelect: (moodId: Mood) => void;
}

const MoodIconDisplay: React.FC<MoodIconDisplayProps> = ({ mood, isSelected, onSelect }) => {
  return (
    <button
      onClick={() => onSelect(mood.id)}
      className={`flex flex-col items-center p-3 rounded-lg transition-all duration-300 ease-in-out transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-soft-clay ${
        isSelected ? 'bg-soft-clay/20' : 'hover:bg-sage-green/20'
      }`}
      aria-label={`Chọn tâm trạng ${mood.label}`}
    >
      <span className={`text-4xl ${isSelected ? mood.color : mood.desaturatedColor} transition-colors duration-300`}>
        {mood.icon}
      </span>
      <span className={`mt-2 text-sm font-medium ${isSelected ? 'text-soft-clay' : 'text-warm-charcoal/80'} transition-colors duration-300`}>
        {mood.label}
      </span>
    </button>
  );
};

export default MoodIconDisplay;
