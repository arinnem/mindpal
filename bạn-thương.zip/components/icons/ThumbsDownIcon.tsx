
import React from 'react';

export const ThumbsDownIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M7 14V2"/>
    <path d="M15 14v6.4c0 .331-.196.4-.465.4h-1.94a2.5 2.5 0 01-2.5-2.5V14H7V2h11.968a2 2 0 011.992 1.849l.04 2.502A2 2 0 0119 8.5V12a2 2 0 01-2 2h-2.068A2 2 0 0113 15v1.5a2 2 0 002 2z"/>
  </svg>
);
