
import React from 'react';

export const LightbulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M9 18h6M12 22V18M12 14a6 6 0 00-3.33-5.33L7 7a5 5 0 0110 0l-1.67 1.67A6 6 0 0012 14z"></path>
    <path d="M12 2a2.828 2.828 0 012.828 2.828A2.828 2.828 0 0112 7.656A2.828 2.828 0 019.172 4.828A2.828 2.828 0 0112 2z"></path>
  </svg>
);
