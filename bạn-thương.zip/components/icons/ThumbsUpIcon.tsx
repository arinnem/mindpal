
import React from 'react';

export const ThumbsUpIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M7 10v12"/>
    <path d="M15 10V3.6C15 3.269 14.804 3 14.535 3h-1.94A2.5 2.5 0 0010 5.5V10H7v12h11.968a2 2 0 001.992-1.849l.04-2.502A2 2 0 0019 15.5V12a2 2 0 00-2-2h-2.068A2 2 0 0013 9V7.5a2 2 0 012-2z"/>
  </svg>
);
