
import React from 'react';

export const SparklesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" {...props}>
    <path d="M12 .5l1.25 2.5 2.5 1.25-2.5 1.25L12 8l-1.25-2.5-2.5-1.25 2.5-1.25L12 .5zm0 15l-1.25 2.5-2.5 1.25 2.5 1.25L12 23.5l1.25-2.5 2.5-1.25-2.5-1.25L12 15.5zM4.5 9.5l-1.5 2.25L.5 13l2.5 1.25L4.5 16.5l1.5-2.25L8.5 13l-2.5-1.25L4.5 9.5zm15 0l-1.5 2.25L15.5 13l2.5 1.25L19.5 16.5l1.5-2.25L23.5 13l-2.5-1.25L19.5 9.5z"/>
  </svg>
);
