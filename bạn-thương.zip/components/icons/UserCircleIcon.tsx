
import React from 'react';

export const UserCircleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...props}>
    <path d="M5.52 19c.64-2.2 1.84-3.9 3.48-5.09A5.99 5.99 0 0 1 12 12a5.99 5.99 0 0 1 3 1.09c1.59 1.19 2.79 2.89 3.48 5.09"/>
    <circle cx="12" cy="12" r="10"/>
    <circle cx="12" cy="10" r="3"/>
  </svg>
);
