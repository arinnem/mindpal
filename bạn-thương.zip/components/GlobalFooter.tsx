
import React from 'react';
import { APP_NAME, VIETNAMESE_HOTLINES } from '../constants';

const GlobalFooter: React.FC = () => {
  return (
    <footer className="bg-sage-green/30 text-warm-charcoal py-8 mt-12">
      <div className="container mx-auto px-4 text-center">
        <div className="mb-6">
          <h3 className="text-xl font-semibold font-display mb-2 text-warm-charcoal">Cần hỗ trợ khẩn cấp?</h3>
          <p className="text-sm mb-3">Đừng ngần ngại, hãy liên hệ ngay:</p>
          <ul className="space-y-1">
            {VIETNAMESE_HOTLINES.map((hotline) => (
              <li key={hotline.name} className="text-sm">
                <span className="font-semibold">{hotline.name}:</span> {hotline.number}
              </li>
            ))}
          </ul>
        </div>
        <div className="flex justify-center space-x-6 mb-4 text-sm">
          <a href="#/about" className="hover:text-soft-clay transition-colors">Về {APP_NAME}</a>
          <a href="#/privacy" className="hover:text-soft-clay transition-colors">Chính sách Bảo mật</a>
          <a href="#/terms" className="hover:text-soft-clay transition-colors">Điều khoản sử dụng</a>
        </div>
        <p className="text-xs text-warm-charcoal/80">
          © {new Date().getFullYear()} {APP_NAME}. Một nơi trú ẩn dịu dàng.
        </p>
      </div>
    </footer>
  );
};

export default GlobalFooter;
