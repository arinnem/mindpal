
import React, { useState, useEffect } from 'react';
import { Mood, MoodOption } from '../types';
import { MOOD_OPTIONS, APP_NAME } from '../constants';
import MoodIconDisplay from '../components/MoodIconDisplay';
import FeatureCard from '../components/FeatureCard';
import ChatInterface from '../components/ChatInterface';
import Button from '../components/Button';
import { MessageSquareTextIcon } from '../components/icons/MessageSquareTextIcon';

const HomePage: React.FC = () => {
  const [selectedMood, setSelectedMood] = useState<Mood | null>(null);
  const [chatInputValue, setChatInputValue] = useState('');
  const [isChatActive, setIsChatActive] = useState(false);
  const [chatPlaceholder, setChatPlaceholder] = useState("Mình cùng kể cho nhau nghe vài câu chuyện nhỏ, cho ngày hôm nay thêm dịu dàng nhé?");
  const [initialChatMessageForChatInterface, setInitialChatMessageForChatInterface] = useState<string | undefined>(undefined);

  useEffect(() => {
    if (selectedMood) {
      const moodSpecificPlaceholders: Record<Mood, string> = {
        [Mood.Happy]: "Chia sẻ niềm vui của bạn với tớ nào!",
        [Mood.Neutral]: "Có điều gì bạn muốn kể không? Tớ lắng nghe nè.",
        [Mood.Sad]: "Tớ ở đây lắng nghe. Cứ kể ra cho nhẹ lòng nhé.",
        [Mood.Tired]: "Mệt rồi phải không? Nghỉ một chút rồi kể tớ nghe nha.",
        [Mood.Confused]: "Có điều gì đang làm bạn rối bời? Kể tớ nghe xem sao.",
      };
      setChatPlaceholder(moodSpecificPlaceholders[selectedMood]);
    } else {
      setChatPlaceholder("Mình cùng kể cho nhau nghe vài câu chuyện nhỏ, cho ngày hôm nay thêm dịu dàng nhé?");
    }
  }, [selectedMood]);

  const handleMoodSelect = (moodId: Mood) => {
    setSelectedMood(moodId === selectedMood ? null : moodId); // Toggle selection
  };

  const handleStartChat = () => {
    if (chatInputValue.trim() !== '') {
      setInitialChatMessageForChatInterface(chatInputValue);
      setIsChatActive(true);
    } else if (selectedMood) {
       // Start chat with only mood, AI can initiate
      setInitialChatMessageForChatInterface(undefined); // No user text, but mood is set
      setIsChatActive(true);
    } else {
      // Prompt user to select mood or type something if they click button with no input
      setChatPlaceholder("Hãy chọn một cảm xúc hoặc gõ điều bạn muốn chia sẻ nhé!");
    }
  };
  
  if (isChatActive) {
    return (
      <div className="w-full max-w-3xl mx-auto" style={{ height: 'calc(100vh - 150px)' /* Adjust based on header/footer */ }}>
        <ChatInterface 
          initialMessage={initialChatMessageForChatInterface} 
          initialMood={selectedMood || undefined}
          onCloseChat={() => {
            setIsChatActive(false);
            setSelectedMood(null); // Reset mood when chat closes
            setChatInputValue(''); // Reset input
          }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-12 md:space-y-16">
      {/* Welcome Nook Hero Section */}
      <section className="text-center py-12 md:py-16 bg-gradient-to-br from-warm-linen via-soft-clay/10 to-sage-green/10 rounded-xl shadow-sm">
        <div className="container mx-auto px-4">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold font-display text-warm-charcoal mb-4 leading-tight">
            Chào bạn thương của tớ.
          </h1>
          <p className="text-lg md:text-xl text-warm-charcoal/80 mb-8 max-w-2xl mx-auto">
            Mong là hôm nay mọi điều đến với bạn đều thật hiền.
          </p>

          <div className="mb-10">
            <p className="text-warm-charcoal mb-4 text-md">Hôm nay bạn cảm thấy thế nào?</p>
            <div className="flex justify-center space-x-2 sm:space-x-4">
              {MOOD_OPTIONS.map((mood) => (
                <MoodIconDisplay
                  key={mood.id}
                  mood={mood}
                  isSelected={selectedMood === mood.id}
                  onSelect={handleMoodSelect}
                />
              ))}
            </div>
          </div>
          
          <div className="max-w-xl mx-auto">
            <div className="flex flex-col sm:flex-row items-center space-y-3 sm:space-y-0 sm:space-x-3 bg-white p-3 rounded-lg shadow-md border border-soft-clay/30">
              <input
                type="text"
                value={chatInputValue}
                onChange={(e) => setChatInputValue(e.target.value)}
                placeholder={chatPlaceholder}
                className="w-full p-3 border-none rounded-md focus:ring-2 focus:ring-soft-clay transition bg-transparent placeholder-warm-charcoal/60 text-warm-charcoal"
                onKeyPress={(e) => e.key === 'Enter' && handleStartChat()}
              />
              <Button 
                onClick={handleStartChat} 
                className="w-full sm:w-auto"
                leftIcon={<MessageSquareTextIcon className="w-5 h-5"/>}
              >
                Gửi lời nhắn
              </Button>
            </div>
             {selectedMood && chatInputValue.trim() === '' && (
                <p className="text-xs text-warm-charcoal/70 mt-2">Hoặc bạn có thể bắt đầu trò chuyện chỉ với tâm trạng đã chọn.</p>
            )}
          </div>
        </div>
      </section>

      {/* Feature Portal */}
      <section className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-semibold font-display text-center text-warm-charcoal mb-8 md:mb-12">
          Khám phá cùng {APP_NAME}
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          <FeatureCard
            title="Tâm sự mỏng"
            description="Không gian riêng tư để bạn ghi lại những dòng suy nghĩ, được AI gợi ý chủ đề một cách tinh tế."
            linkTo="/journal"
            imageUrl="https://picsum.photos/seed/journal/400/300"
            accentColor="bg-sage-green"
          />
          <FeatureCard
            title="Hình dáng tôi"
            description="Biến những suy nghĩ tiêu cực thành những 'quái vật' đáng yêu và cùng nhau 'thuần hóa' chúng."
            linkTo="/monsters"
            imageUrl="https://picsum.photos/seed/monsters/400/300"
            accentColor="bg-soft-clay"
          />
          <FeatureCard
            title="Khám phá"
            description="Tìm kiếm các bài tập, câu chuyện và hoạt động giúp bạn cảm thấy tốt hơn mỗi ngày."
            linkTo="/explore"
            imageUrl="https://picsum.photos/seed/explore/400/300"
            accentColor="bg-yellow-500" 
          />
        </div>
      </section>
    </div>
  );
};

export default HomePage;
